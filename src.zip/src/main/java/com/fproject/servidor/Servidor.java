package com.fproject.servidor;

public class Servidor {
}
